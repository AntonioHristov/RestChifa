# PROYECTO_DIW
    Proyecto de DIW EV_2.
# WIREFRAME
    Imagen wireframe de programa.
![Image text](https://github.com/Xing2707/PROYECTO_DIW/blob/main/IMG/wireframe.png)

