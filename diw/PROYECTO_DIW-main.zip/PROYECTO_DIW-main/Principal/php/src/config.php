<?php

$CONFIG['title'] = "localTeteria";
$CONFIG['db_name']="localTeteria";
$CONFIG['db_user']="localTeteria";
$CONFIG['db_pass']="1234";
$CONFIG['db_host']="localhost";
?>