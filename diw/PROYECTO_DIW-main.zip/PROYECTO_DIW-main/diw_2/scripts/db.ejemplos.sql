INSERT INTO usuarios (nombre, passwd, img, correo, descripcion)
    VALUES ('admin', '$2y$10$bH6ZpLC3P4hEkCcp5TiHmOgn37KyZZqs9blKaMi8BkeuMwK/7hm7a','admin.png', 'jorge.duenas@educa.madrid.org', 'Blablablabla');

INSERT INTO usuarios (nombre, passwd, img, correo, descripcion)
    VALUES ('pepe', '$2y$10$PiLMC2KTlDHeFeZtp/WV7ehhk.Q3T0X2ajqy3DKjrvI01cNimLy6u','pepe.png', 'pepe@educa.madrid.org', 'Blablablabla');
    